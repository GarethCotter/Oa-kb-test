# Search & update pipeline — implementation notes

The site ships with keyword search that works with no backend. The LLM answer
layer sits on top of it: it adds a plain-English answer above the results, and
if it ever fails or is switched off, the keyword links still work.

## Search: two Haiku calls per question

**Call 1 — route.** Input: the question plus a routing index built from
`assets/search-index.json` (title, section, audience, one-line summary for all
174 articles — about 10k tokens). Mark that index as a cache breakpoint: it is
identical on every request, so after the first call it bills at the cached rate.
Ask for JSON only: `{"slugs": ["07-.../how-to-...", ...], "audience": "organiser"}`,
max 3 slugs.

**Call 2 — answer.** Input: the full markdown of just those articles (2–4k
tokens) plus the question. Ask for a short answer in plain English, British
spelling, no jargon, and the source article path. Instruct it to say it does not
know and offer the support link rather than guess — a wrong confident answer is
worse than no answer for this audience.

Rough cost per question at Haiku 4.5 rates ($1/M in, $5/M out, cached input 90%
cheaper): well under a cent. Cache the whole routing index rather than
re-sending it; that is where nearly all the saving is.

Endpoint shape: `POST /api/search {question}` -> `{answer, sources:[{title,path}]}`.
Any serverless host works (the site itself is static). Never put the API key in
the page — the browser calls your endpoint, your endpoint calls Anthropic.

## Logging

Log every question, the routed slugs, and whether the user then clicked a
source. That log is the roadmap for which articles to write next — questions
that route badly or get no click are content gaps.

## Updates: describe a change, the model edits the article

Low volume, quality-critical, so use Sonnet rather than Haiku.

1. You type what changed in plain English.
2. Call 1 routes to the affected article(s) using the same cached index.
3. Call 2 receives the current markdown and returns the full revised markdown,
   preserving frontmatter and heading structure.
4. Write to a branch and open a pull request — a human approves before it goes
   live. Rebuild the site on merge.

Keep the frontmatter fields (`title`, `section`, `audience`, `plan`,
`source_url`, `merged_from`) intact on every edit; the routing index is
generated from them.

## First jobs for the pipeline once it runs

- Smooth the six consolidated symposia articles (currently concatenated sources).
- Fill in the `plan:` field where it still reads "review: confirm plan gating".
- Place the two unmapped FAQ answers in `_review-unmapped-faq.md`.
